﻿/*
 Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("easyimage","ku",{commands:{fullImage:"پڕ بە پڕی وێنەکە",sideImage:"لای وێنەکە",altText:"گۆڕینی جێگرەوەی تێکستی وێنەکە",upload:"بارکردنی وێنە"},uploadFailed:"وێنەکەت ناتوانرێت بارکرێت بەهۆی هەڵەی پەیوەندیکردن بەتۆڕی نێت. "});