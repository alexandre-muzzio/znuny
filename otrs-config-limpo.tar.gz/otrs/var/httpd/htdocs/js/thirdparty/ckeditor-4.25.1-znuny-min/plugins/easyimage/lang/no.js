﻿/*
 Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("easyimage","no",{commands:{fullImage:"Full Size Image",sideImage:"Side Image",altText:"Change image alternative text",upload:"Last opp bilde"},uploadFailed:"Bildet ble ikke lastet opp på grunn av en nettverksfeil."});